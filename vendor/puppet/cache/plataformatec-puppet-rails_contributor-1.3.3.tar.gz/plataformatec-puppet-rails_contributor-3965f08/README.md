# Rails contributor

A puppet module for developing the Rails project.

# Required Modules for Rails contributor

* boxen
* repository
* homebrew
* stdlib
* sysctl
* postgresql
* mysql
* gcc
* openssl
* ruby

## Usage

```puppet
include rails_contributor
```

## Development

Write code. Check the `script` directory for other useful tools.
